#include <stdlib.h>
#include <ncurses.h>
#include "ncurses_addons.h"


int main(void)
{
    /************************************************/
    /*          ncurses initialization              */
    /************************************************/
    init_ncurses();


    /************************************************/
    /*          Beginning of the program            */
    /************************************************/

    // EXAMPLE: Cursor move and text in color printing...
    move(10, 25);
    attron(COLOR_PAIR(RED_ON_BLACK));
    printw("A red colored text in the middle of the window\n");
    attroff(COLOR_PAIR(RED_ON_BLACK));

    // refresh window needed to display all the text
    refresh();
    // waiting for a key press
    getch();


    /************************************************/
    /*          End of the program                  */
    /************************************************/
    // Close properly ncurses
    endwin();

    return EXIT_SUCCESS;
}
