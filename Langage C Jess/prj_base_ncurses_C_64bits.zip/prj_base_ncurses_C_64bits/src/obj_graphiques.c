#include "obj_graphiques.h"


void afficher_point(Point p)
{

}
