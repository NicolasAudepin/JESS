#ifndef OBJ_GRAPHIQUES_H_INCLUDED
#define OBJ_GRAPHIQUES_H_INCLUDED

typedef struct
{
    int x, y;
    int couleur;
} Point;

void afficher_point(Point p);

#endif // OBJ_GRAPHIQUES_H_INCLUDED
